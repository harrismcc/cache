#include "cachelab.h"
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

//Riley Mangan, Harris McCullers, and Kevin Sasaki

// struct ojb{
//     int value;
//     int tag;
//     int block;
// }

// struct obj load(struct obj cache, int address, int size){
//     return cache;
// }

// struct obj store(struct obj cache, int address, int size){
//     return cache;
// }

int cache_sim(){
    //b = bytes per block
    //s = # sets in cache
    //E = # blocks per set
    // int s;
    // struct obj cache[s];
    // char type[1];
    // int address, size;
    // while(scanf("%s %d %d", &type, &address, &size) == 3){
    //     if(type[0] != "I"){
    //         continue;
    //     }
    //     else if(type == "L"){
    //         cache = load(cache, address, size);
    //     }
    //     else if(type == "S"){
    //         cache = store(cache, address, size);
    //     }
    //     else if(type == "M"){
    //         cache = load(cache, address, size);
    //         cache = store(cache, address, size);
    //     }
    // }
    return 0;
}

int main(int argc, char **argv)
{
    int i;
    int s, E, b;
    char *fname;
    
    for(i = 0; i < argc; i++){
        printf("argv[%d] = %s\n", i, argv[i]);
        printf("isdigit: %s %d\n", argv[i], isdigit(argv[i]));
        if(!strcmp(argv[i], "-s")){
            printf("a\n");
            if(isdigit(argv[i+1] - '0')){
                s = atoi(argv[i+1]);
                printf("b\n");
            }
            else{
                //TODO change this default value
                //s = 1;
                printf("c\n");
                s = 1;
            }
        }
        else if(!strcmp(argv[i], "-E")){
            if(!isalpha(argv[i+1])){
                E = atoi(argv[i+1]);
            }
            else{
                //TODO change this default value
                E = 1;
                printf("f\n");
            }
        }
        else if(!strcmp(argv[i], "-b")){
            if(!isalpha(argv[i+1])){
                b = atoi(argv[i+1]);
            }
            else{
                //TODO change this default value
                b = 1;
            }
        }
        else if(!strcmp(argv[i], "-t")){
            fname = argv[i+1];
        }
    }
    printf("s, E, b, t: %d %d %d %s\n",s,E,b,fname);

    printSummary(0, 0, 0);
    return 0;
}
